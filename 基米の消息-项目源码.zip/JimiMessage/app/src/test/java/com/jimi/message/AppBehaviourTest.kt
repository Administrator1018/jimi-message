package com.jimi.message

import android.app.Application
import android.app.NotificationManager
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import androidx.work.workDataOf
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29, 35])
class AppBehaviourTest {

    private val context: Application
        get() = ApplicationProvider.getApplicationContext()

    @Test
    fun activityStartsAndShowsDefaultState() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()

        val status = activity.findViewById<TextView>(R.id.textStatus)
        assertNotNull(status)
        assertTrue(status.text.isNotBlank())

        val toneGroup = activity.findViewById<ChipGroup>(R.id.chipGroupTones)
        assertEquals(Tone.entries.size, toneGroup.childCount)
        val checkedTones = (0 until toneGroup.childCount)
            .count { (toneGroup.getChildAt(it) as Chip).isChecked }
        assertEquals(2, checkedTones)

        val presets = activity.findViewById<ChipGroup>(R.id.chipGroupPresets)
        assertEquals(8, presets.childCount)

        val preview = activity.findViewById<TextView>(R.id.textPreview)
        assertTrue(preview.text.isNotBlank())

        assertFalse(AppPrefs(context).enabled)
    }

    @Test
    fun everyToneCanProduceItsOwnMessage() {
        Tone.entries.forEach { tone ->
            repeat(40) {
                val message = MessageBank.pick(listOf(tone.id))
                assertEquals(tone, message.tone)
                assertTrue(message.text.isNotBlank())
            }
        }
    }

    @Test
    fun recentMessagesAreNotRepeatedImmediately() {
        val tones = Tone.entries.map { it.id }
        val recent = HashSet<String>()
        repeat(60) {
            val message = MessageBank.pick(tones, recentKeys = recent)
            assertFalse("抽到了刚发过的消息: ${message.text}", message.key in recent)
            recent.add(message.key)
            if (recent.size > 40) recent.clear()
        }
    }

    @Test
    fun quietHoursCoverOvernightWindow() {
        val prefs = AppPrefs(context)
        prefs.quietEnabled = true
        prefs.quietStartMinute = 23 * 60
        prefs.quietEndMinute = 7 * 60

        assertTrue(prefs.inQuietHours(todayAt(23, 30)))
        assertTrue(prefs.inQuietHours(todayAt(3, 0)))
        assertTrue(prefs.inQuietHours(todayAt(6, 59)))
        assertFalse(prefs.inQuietHours(todayAt(7, 0)))
        assertFalse(prefs.inQuietHours(todayAt(12, 0)))

        prefs.quietEnabled = false
        assertFalse(prefs.inQuietHours(todayAt(23, 30)))
    }

    @Test
    fun forcedWorkerPostsNotificationWithoutCounting() {
        grantNotificationPermission()
        val prefs = AppPrefs(context)
        prefs.tones = Tone.defaultSelection.toSet()
        prefs.enabled = true
        prefs.quietEnabled = false

        val worker = TestListenableWorkerBuilder<MessageWorker>(context)
            .setInputData(workDataOf(MessageWorker.KEY_FORCE to true))
            .build()
        assertEquals(ListenableWorker.Result.success(), worker.doWork())

        assertEquals(1, notificationCount())
        // 强制发送（开机问候 / 稍后再提醒）不计入统计
        assertEquals(0, prefs.sentCount)
        assertFalse(prefs.recentKeys().isEmpty())
    }

    @Test
    fun scheduledWorkerCountsOnceAndRespectsQuietHours() {
        grantNotificationPermission()
        val prefs = AppPrefs(context)
        prefs.tones = Tone.defaultSelection.toSet()
        prefs.enabled = true
        prefs.quietEnabled = false

        TestListenableWorkerBuilder<MessageWorker>(context).build().doWork()
        assertEquals(1, notificationCount())
        assertEquals(1, prefs.sentCount)

        // 进入安静时段后不再打扰
        prefs.quietEnabled = true
        prefs.quietStartMinute = 0
        prefs.quietEndMinute = 1439
        TestListenableWorkerBuilder<MessageWorker>(context).build().doWork()
        assertEquals(1, notificationCount())
        assertEquals(1, prefs.sentCount)
    }

    @Test
    fun workerStaysSilentWhenDisabled() {
        grantNotificationPermission()
        val prefs = AppPrefs(context)
        prefs.enabled = false

        TestListenableWorkerBuilder<MessageWorker>(context).build().doWork()
        assertEquals(0, notificationCount())
        assertEquals(0, prefs.sentCount)
    }

    private fun notificationCount(): Int =
        shadowOf(context.getSystemService(NotificationManager::class.java)).size()

    private fun grantNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            shadowOf(context).grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun todayAt(hour: Int, minute: Int): Long =
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
}
