package com.jimi.message

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.format.DateFormat
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: AppPrefs

    private var updatingUi = false
    private var pendingAfterPermission: (() -> Unit)? = null
    private val presetChips = LinkedHashMap<Int, Chip>()

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.CHINA)
    private val dateTimeFormat = SimpleDateFormat("M月d日 HH:mm", Locale.CHINA)

    private val switchEnabled: MaterialSwitch by lazy { findViewById(R.id.switchEnabled) }
    private val switchQuiet: MaterialSwitch by lazy { findViewById(R.id.switchQuiet) }
    private val textStatus: TextView by lazy { findViewById(R.id.textStatus) }
    private val chipGroupTones: ChipGroup by lazy { findViewById(R.id.chipGroupTones) }
    private val chipGroupPresets: ChipGroup by lazy { findViewById(R.id.chipGroupPresets) }
    private val sliderInterval: Slider by lazy { findViewById(R.id.sliderInterval) }
    private val textIntervalValue: TextView by lazy { findViewById(R.id.textIntervalValue) }
    private val toggleMode: MaterialButtonToggleGroup by lazy { findViewById(R.id.toggleMode) }
    private val groupInterval: LinearLayout by lazy { findViewById(R.id.groupInterval) }
    private val groupDaily: LinearLayout by lazy { findViewById(R.id.groupDaily) }
    private val btnDailyTime: MaterialButton by lazy { findViewById(R.id.btnDailyTime) }
    private val btnQuietStart: MaterialButton by lazy { findViewById(R.id.btnQuietStart) }
    private val btnQuietEnd: MaterialButton by lazy { findViewById(R.id.btnQuietEnd) }
    private val textPreview: TextView by lazy { findViewById(R.id.textPreview) }
    private val textPreviewTone: TextView by lazy { findViewById(R.id.textPreviewTone) }
    private val btnShuffle: MaterialButton by lazy { findViewById(R.id.btnShuffle) }
    private val btnTest: MaterialButton by lazy { findViewById(R.id.btnTest) }
    private val btnNotificationSettings: MaterialButton by lazy { findViewById(R.id.btnNotificationSettings) }
    private val btnBattery: MaterialButton by lazy { findViewById(R.id.btnBattery) }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val action = pendingAfterPermission
            pendingAfterPermission = null
            if (granted) {
                action?.invoke()
            } else {
                toast(getString(R.string.toast_permission_denied))
                refreshUi()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = AppPrefs(this)
        Notifier.ensureChannel(this)

        buildToneChips()
        buildPresetChips()
        bindListeners()
        refreshUi()
    }

    // ---------------------------------------------------------------- 口吻

    private fun buildToneChips() {
        chipGroupTones.removeAllViews()
        Tone.entries.forEach { tone ->
            val chip = layoutInflater.inflate(R.layout.item_chip, chipGroupTones, false) as Chip
            chip.id = View.generateViewId()
            chip.text = tone.label
            chip.contentDescription = tone.blurb
            chip.setOnCheckedChangeListener { _, _ -> onToneChanged() }
            chipGroupTones.addView(chip)
        }
    }

    private fun toneChip(index: Int): Chip? = chipGroupTones.getChildAt(index) as? Chip

    private fun onToneChanged() {
        if (updatingUi) return
        val selected = selectedTones()
        if (selected.isEmpty()) {
            toneChip(0)?.isChecked = true
            toast(getString(R.string.toast_need_tone))
            return
        }
        prefs.tones = selected.toSet()
        showPreview()
    }

    private fun selectedTones(): List<String> = Tone.entries.mapNotNull { tone ->
        if (toneChip(tone.ordinal)?.isChecked == true) tone.id else null
    }

    // ---------------------------------------------------------------- 频率

    private fun buildPresetChips() {
        chipGroupPresets.removeAllViews()
        presetChips.clear()
        PRESETS.forEach { minutes ->
            val chip = layoutInflater.inflate(R.layout.item_chip, chipGroupPresets, false) as Chip
            chip.id = View.generateViewId()
            chip.text = formatInterval(minutes)
            chip.setOnClickListener {
                prefs.intervalMinutes = minutes
                refreshIntervalParts()
                applySchedule()
            }
            chipGroupPresets.addView(chip)
            presetChips[minutes] = chip
        }
    }

    private fun onIntervalSliderChanged(value: Float) {
        // 以 5 分钟为最小粒度
        prefs.intervalMinutes = (value.toInt() / 5) * 5
        refreshIntervalParts()
    }

    private fun refreshIntervalParts() {
        val minutes = prefs.intervalMinutes
        val wasUpdating = updatingUi
        updatingUi = true
        sliderInterval.value = minutes.toFloat()
        updatingUi = wasUpdating
        textIntervalValue.text = getString(R.string.interval_value, formatInterval(minutes))
        presetChips.forEach { (preset, chip) -> chip.isChecked = preset == minutes }
    }

    private fun formatInterval(minutes: Int): String {
        val hours = minutes / 60
        val rest = minutes % 60
        return when {
            minutes < 60 -> getString(R.string.unit_minutes, minutes)
            rest == 0 -> getString(R.string.unit_hours, hours)
            else -> getString(R.string.unit_hours_minutes, hours, rest)
        }
    }

    // ---------------------------------------------------------------- 界面刷新

    private fun refreshUi() {
        updatingUi = true

        switchEnabled.isChecked = prefs.enabled
        switchQuiet.isChecked = prefs.quietEnabled

        Tone.entries.forEach { tone ->
            toneChip(tone.ordinal)?.isChecked = tone.id in prefs.tones
        }

        val daily = prefs.mode == AppPrefs.MODE_DAILY
        toggleMode.check(if (daily) R.id.btnModeDaily else R.id.btnModeInterval)
        groupInterval.visibility = if (daily) View.GONE else View.VISIBLE
        groupDaily.visibility = if (daily) View.VISIBLE else View.GONE

        btnDailyTime.text =
            getString(R.string.daily_time, formatTime(prefs.dailyHour * 60 + prefs.dailyMinute))
        btnQuietStart.text = getString(R.string.quiet_start, formatTime(prefs.quietStartMinute))
        btnQuietEnd.text = getString(R.string.quiet_end, formatTime(prefs.quietEndMinute))
        btnQuietStart.isEnabled = prefs.quietEnabled
        btnQuietEnd.isEnabled = prefs.quietEnabled

        updatingUi = false

        refreshIntervalParts()
        refreshStatus()
        if (textPreview.text.isNullOrBlank()) showPreview()
    }

    private fun refreshStatus() {
        val status = if (!prefs.enabled) {
            getString(R.string.status_off)
        } else {
            val next = prefs.nextRunAt
            val whenText =
                if (next <= 0L) getString(R.string.status_soon) else dateTimeFormat.format(Date(next))
            getString(R.string.status_on, whenText, prefs.sentCount)
        }
        textStatus.text = status
    }

    private fun showPreview() {
        val message = MessageBank.pick(prefs.tones, recentKeys = prefs.recentKeys())
        textPreview.text = message.text
        textPreviewTone.text = getString(R.string.preview_tone, message.tone.label)
    }

    private fun formatTime(minutesOfDay: Int): String {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutesOfDay / 60)
            set(Calendar.MINUTE, minutesOfDay % 60)
            set(Calendar.SECOND, 0)
        }
        return timeFormat.format(calendar.time)
    }

    // ---------------------------------------------------------------- 监听

    private fun bindListeners() {
        switchEnabled.setOnCheckedChangeListener { _, checked ->
            if (updatingUi) return@setOnCheckedChangeListener
            if (checked) {
                withNotificationPermission { setEnabled(true) }
            } else {
                setEnabled(false)
            }
        }

        switchQuiet.setOnCheckedChangeListener { _, checked ->
            if (updatingUi) return@setOnCheckedChangeListener
            prefs.quietEnabled = checked
            refreshUi()
        }

        sliderInterval.addOnChangeListener { _, value, fromUser ->
            if (updatingUi || !fromUser) return@addOnChangeListener
            onIntervalSliderChanged(value)
        }
        sliderInterval.addOnSliderTouchListener(
            object : Slider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: Slider) = Unit

                override fun onStopTrackingTouch(slider: Slider) {
                    applySchedule()
                }
            },
        )

        toggleMode.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (updatingUi || !isChecked) return@addOnButtonCheckedListener
            prefs.mode =
                if (checkedId == R.id.btnModeDaily) AppPrefs.MODE_DAILY else AppPrefs.MODE_INTERVAL
            refreshUi()
            applySchedule()
        }

        btnDailyTime.setOnClickListener {
            pickTime(prefs.dailyHour * 60 + prefs.dailyMinute) { minutes ->
                prefs.dailyHour = minutes / 60
                prefs.dailyMinute = minutes % 60
                refreshUi()
                applySchedule()
            }
        }

        btnQuietStart.setOnClickListener {
            pickTime(prefs.quietStartMinute) { minutes ->
                prefs.quietStartMinute = minutes
                refreshUi()
            }
        }

        btnQuietEnd.setOnClickListener {
            pickTime(prefs.quietEndMinute) { minutes ->
                prefs.quietEndMinute = minutes
                refreshUi()
            }
        }

        btnShuffle.setOnClickListener { showPreview() }

        btnTest.setOnClickListener {
            withNotificationPermission {
                val message = MessageBank.pick(prefs.tones, recentKeys = prefs.recentKeys())
                Notifier.show(this, message)
                toast(getString(R.string.toast_test_sent))
            }
        }

        btnNotificationSettings.setOnClickListener { openNotificationSettings() }
        btnBattery.setOnClickListener { requestBatteryExemption() }
    }

    private fun setEnabled(enabled: Boolean) {
        prefs.enabled = enabled
        Scheduler.apply(this, withGreeting = enabled)
        refreshUi()
        if (enabled) {
            toast(getString(R.string.toast_enabled))
        } else {
            toast(getString(R.string.toast_disabled))
        }
    }

    private fun applySchedule() {
        Scheduler.apply(this)
        refreshStatus()
    }

    // ---------------------------------------------------------------- 权限 / 系统设置

    private fun withNotificationPermission(action: () -> Unit) {
        val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (!needsPermission) {
            action()
            return
        }
        pendingAfterPermission = action
        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun openNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        runCatching { startActivity(intent) }
            .onFailure { runCatching { startActivity(appDetailsIntent()) } }
    }

    private fun appDetailsIntent(): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.fromParts("package", packageName, null))

    private fun requestBatteryExemption() {
        val power = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (power?.isIgnoringBatteryOptimizations(packageName) == true) {
            toast(getString(R.string.toast_battery_ok))
            return
        }
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            .setData(Uri.fromParts("package", packageName, null))
        runCatching { startActivity(intent) }
            .onFailure {
                runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    .onFailure { toast(getString(R.string.toast_battery_manual)) }
            }
    }

    private fun pickTime(initialMinutesOfDay: Int, onPicked: (Int) -> Unit) {
        TimePickerDialog(
            this,
            { _, hour, minute -> onPicked(hour * 60 + minute) },
            initialMinutesOfDay / 60,
            initialMinutesOfDay % 60,
            DateFormat.is24HourFormat(this),
        ).show()
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        /** 快捷频率：15 分钟 ~ 24 小时 */
        val PRESETS = listOf(15, 30, 60, 120, 240, 480, 720, 1440)
    }
}
