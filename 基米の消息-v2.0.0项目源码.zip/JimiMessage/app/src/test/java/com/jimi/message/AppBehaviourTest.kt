package com.jimi.message

import android.app.Application
import android.app.NotificationManager
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import androidx.work.workDataOf
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29, 35])
class AppBehaviourTest {

    private val context: Application
        get() = ApplicationProvider.getApplicationContext()

    @Test
    fun activityStartsAndShowsDefaultState() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()

        val status = activity.findViewById<TextView>(R.id.textStatus)
        assertNotNull(status)
        assertTrue(status.text.isNotBlank())

        val toneGroup = activity.findViewById<ChipGroup>(R.id.chipGroupTones)
        assertEquals(Tone.entries.size, toneGroup.childCount)
        val checkedTones = (0 until toneGroup.childCount)
            .count { (toneGroup.getChildAt(it) as Chip).isChecked }
        assertEquals(2, checkedTones)

        val preview = activity.findViewById<TextView>(R.id.textPreview)
        assertTrue(preview.text.isNotBlank())

        val summary = activity.findViewById<TextView>(R.id.textCustomSummary)
        assertTrue(summary.text.contains(MessageBank.totalCount(context).toString()))

        assertFalse(AppPrefs(context).enabled)
    }

    @Test
    fun builtInBankHasAtLeastOneThousandMessages() {
        val all = MessageBank.all(context)
        assertTrue("内置消息只有 ${all.size} 条", all.size >= 1000)

        Tone.entries.forEach { tone ->
            Slot.entries.filter { it != Slot.ANY }.forEach { slot ->
                assertTrue(
                    "$tone 缺少 $slot 时段的消息",
                    all.any { it.tone == tone && it.slot == slot },
                )
            }
        }
    }

    @Test
    fun slotFollowsSystemHour() {
        assertEquals(Slot.NIGHT, Slot.ofHour(23))
        assertEquals(Slot.NIGHT, Slot.ofHour(0))
        assertEquals(Slot.NIGHT, Slot.ofHour(4))
        assertEquals(Slot.DAWN, Slot.ofHour(5))
        assertEquals(Slot.MORNING, Slot.ofHour(9))
        assertEquals(Slot.NOON, Slot.ofHour(12))
        assertEquals(Slot.AFTERNOON, Slot.ofHour(15))
        assertEquals(Slot.EVENING, Slot.ofHour(19))
    }

    @Test
    fun pickedMessageAlwaysMatchesRequestedTimeSlot() {
        val allowed = MessageBank.all(context)
            .filter { it.slot == Slot.NOON || it.slot == Slot.ANY }
            .map { it.text }
            .toSet()

        val noon = todayAt(12, 0)
        repeat(200) {
            val picked = MessageBank.pick(context, tones = Tone.entries.map { it.id }, now = noon)
            assertTrue("午间抽到了非午间消息：${picked.text}", picked.text in allowed)
        }

        val nightAllowed = MessageBank.all(context)
            .filter { it.slot == Slot.NIGHT || it.slot == Slot.ANY }
            .map { it.text }
            .toSet()
        val night = todayAt(23, 30)
        repeat(200) {
            val picked = MessageBank.pick(context, tones = Tone.entries.map { it.id }, now = night)
            assertTrue("深夜抽到了非深夜消息：${picked.text}", picked.text in nightAllowed)
        }
    }

    @Test
    fun everyToneCanProduceItsOwnMessage() {
        Tone.entries.forEach { tone ->
            repeat(40) {
                val picked = MessageBank.pick(context, tones = listOf(tone.id))
                assertTrue(picked.text.isNotBlank())
                assertEquals(tone.label, picked.label)
            }
        }
    }

    @Test
    fun recentMessagesAreNotRepeatedImmediately() {
        val tones = Tone.entries.map { it.id }
        val recent = HashSet<String>()
        repeat(80) {
            val picked = MessageBank.pick(context, tones = tones, recentKeys = recent)
            assertFalse("抽到了刚发过的消息: ${picked.text}", picked.key in recent)
            recent.add(picked.key)
            if (recent.size > 60) recent.clear()
        }
    }

    @Test
    fun customMessagesCanBeAddedListedAndDeleted() {
        val store = CustomMessageStore(context)
        store.clear()

        assertTrue(store.add("宝宝记得喝水"))
        assertTrue(store.add("  今天也要开心呀  "))
        assertFalse("重复内容不应再次添加", store.add("宝宝记得喝水"))
        assertFalse("空白内容不应添加", store.add("   "))
        assertEquals(2, store.size)
        assertEquals("今天也要开心呀", store.all().first())

        val picked = MessageBank.pick(
            context = context,
            tones = listOf(Tone.GENTLE.id),
            custom = store.all(),
        )
        assertTrue(picked.text.isNotBlank())

        store.remove("宝宝记得喝水")
        assertEquals(1, store.size)
        assertFalse(store.all().contains("宝宝记得喝水"))

        store.clear()
        assertEquals(0, store.size)
    }

    @Test
    fun quietHoursCoverOvernightWindow() {
        val prefs = AppPrefs(context)
        prefs.quietEnabled = true
        prefs.quietStartMinute = 23 * 60
        prefs.quietEndMinute = 7 * 60

        assertTrue(prefs.inQuietHours(todayAt(23, 30)))
        assertTrue(prefs.inQuietHours(todayAt(3, 0)))
        assertTrue(prefs.inQuietHours(todayAt(6, 59)))
        assertFalse(prefs.inQuietHours(todayAt(7, 0)))
        assertFalse(prefs.inQuietHours(todayAt(12, 0)))

        prefs.quietEnabled = false
        assertFalse(prefs.inQuietHours(todayAt(23, 30)))
    }

    @Test
    fun forcedWorkerPostsNotificationWithoutCounting() {
        grantNotificationPermission()
        val prefs = AppPrefs(context)
        prefs.tones = Tone.defaultSelection.toSet()
        prefs.enabled = true
        prefs.quietEnabled = false

        val worker = TestListenableWorkerBuilder<MessageWorker>(context)
            .setInputData(workDataOf(MessageWorker.KEY_FORCE to true))
            .build()
        assertEquals(ListenableWorker.Result.success(), worker.doWork())

        assertEquals(1, notificationCount())
        assertEquals(0, prefs.sentCount)
        assertFalse(prefs.recentKeys().isEmpty())
    }

    @Test
    fun scheduledWorkerCountsOnceAndRespectsQuietHours() {
        grantNotificationPermission()
        val prefs = AppPrefs(context)
        prefs.tones = Tone.defaultSelection.toSet()
        prefs.enabled = true
        prefs.quietEnabled = false

        TestListenableWorkerBuilder<MessageWorker>(context).build().doWork()
        assertEquals(1, notificationCount())
        assertEquals(1, prefs.sentCount)

        prefs.quietEnabled = true
        prefs.quietStartMinute = 0
        prefs.quietEndMinute = 1439
        TestListenableWorkerBuilder<MessageWorker>(context).build().doWork()
        assertEquals(1, notificationCount())
        assertEquals(1, prefs.sentCount)
    }

    @Test
    fun workerStaysSilentWhenDisabled() {
        grantNotificationPermission()
        val prefs = AppPrefs(context)
        prefs.enabled = false

        TestListenableWorkerBuilder<MessageWorker>(context).build().doWork()
        assertEquals(0, notificationCount())
        assertEquals(0, prefs.sentCount)
    }

    private fun notificationCount(): Int =
        shadowOf(context.getSystemService(NotificationManager::class.java)).size()

    private fun grantNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            shadowOf(context).grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun todayAt(hour: Int, minute: Int): Long =
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
}
