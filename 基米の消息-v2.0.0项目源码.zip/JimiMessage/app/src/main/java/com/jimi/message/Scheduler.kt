package com.jimi.message

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** 使用 WorkManager 安排后台提醒，系统重启后会自动恢复。 */
object Scheduler {

    private const val UNIQUE_PERIODIC = "jimi_periodic_message"
    private const val UNIQUE_GREETING = "jimi_greeting"

    /** 开启后 25 秒先送上一句问候，让用户马上确认通知是通的。 */
    private const val GREETING_DELAY_MS = 25_000L

    fun apply(context: Context, withGreeting: Boolean = false) {
        val prefs = AppPrefs(context)
        val workManager = WorkManager.getInstance(context)

        if (!prefs.enabled) {
            workManager.cancelUniqueWork(UNIQUE_PERIODIC)
            prefs.nextRunAt = 0L
            return
        }

        val now = System.currentTimeMillis()
        val daily = prefs.mode == AppPrefs.MODE_DAILY
        val delayMillis: Long
        val request: PeriodicWorkRequest

        if (daily) {
            delayMillis = delayUntilNextDaily(prefs, now)
            request = PeriodicWorkRequestBuilder<MessageWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
                .build()
        } else {
            val minutes = prefs.intervalMinutes.coerceAtLeast(AppPrefs.MIN_INTERVAL).toLong()
            delayMillis = TimeUnit.MINUTES.toMillis(minutes)
            request = PeriodicWorkRequestBuilder<MessageWorker>(minutes, TimeUnit.MINUTES)
                .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
                .build()
        }

        workManager.enqueueUniquePeriodicWork(
            UNIQUE_PERIODIC,
            ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE,
            request,
        )
        prefs.nextRunAt = now + delayMillis

        if (withGreeting) {
            workManager.enqueueUniqueWork(
                UNIQUE_GREETING,
                androidx.work.ExistingWorkPolicy.REPLACE,
                MessageWorker.oneOff(delayMillis = GREETING_DELAY_MS, forced = true),
            )
        }
    }

    private fun delayUntilNextDaily(prefs: AppPrefs, now: Long): Long {
        val target = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, prefs.dailyHour)
            set(Calendar.MINUTE, prefs.dailyMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (target.timeInMillis <= now) target.add(Calendar.DAY_OF_YEAR, 1)
        return target.timeInMillis - now
    }
}
