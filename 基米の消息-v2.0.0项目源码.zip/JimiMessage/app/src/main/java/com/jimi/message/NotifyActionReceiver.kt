package com.jimi.message

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.WorkManager

/** 处理通知上的「收到啦」与「5 分钟后再说」。 */
class NotifyActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Notifier.ACTION_DISMISS -> Notifier.cancel(context)

            Notifier.ACTION_SNOOZE -> {
                Notifier.cancel(context)
                WorkManager.getInstance(context).enqueue(
                    MessageWorker.oneOff(delayMillis = SNOOZE_MINUTES * 60_000L, forced = true),
                )
            }
        }
    }

    private companion object {
        const val SNOOZE_MINUTES = 5L
    }
}
