package com.jimi.message

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText

/** 自定义消息的添加与管理界面。 */
class CustomMessagesActivity : AppCompatActivity() {

    private lateinit var store: CustomMessageStore
    private lateinit var adapter: CustomMessageAdapter

    private val textSummary: TextView by lazy { findViewById(R.id.textSummary) }
    private val textEmpty: TextView by lazy { findViewById(R.id.textEmpty) }
    private val editMessage: TextInputEditText by lazy { findViewById(R.id.editMessage) }
    private val btnClear: MaterialButton by lazy { findViewById(R.id.btnClear) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_custom_messages)

        store = CustomMessageStore(this)
        adapter = CustomMessageAdapter { message -> confirmDelete(message) }

        findViewById<RecyclerView>(R.id.listMessages).apply {
            layoutManager = LinearLayoutManager(this@CustomMessagesActivity)
            adapter = this@CustomMessagesActivity.adapter
            setHasFixedSize(false)
        }

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnAdd).setOnClickListener { addCurrentInput() }
        btnClear.setOnClickListener { confirmClear() }

        refresh()
    }

    private fun addCurrentInput() {
        val raw = editMessage.text?.toString().orEmpty()
        when {
            raw.isBlank() -> toast(getString(R.string.toast_custom_empty))
            store.contains(raw) -> toast(getString(R.string.toast_custom_duplicate))
            store.isFull -> toast(getString(R.string.toast_custom_full, CustomMessageStore.MAX_COUNT))
            store.add(raw) -> {
                editMessage.setText("")
                toast(getString(R.string.toast_custom_added))
                refresh()
            }
        }
    }

    private fun confirmDelete(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.custom_delete_title)
            .setMessage(R.string.custom_delete_message)
            .setNegativeButton(R.string.custom_cancel, null)
            .setPositiveButton(R.string.custom_delete_ok) { _, _ ->
                store.remove(message)
                toast(getString(R.string.toast_custom_deleted))
                refresh()
            }
            .show()
    }

    private fun confirmClear() {
        if (store.size == 0) return
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.custom_clear_title)
            .setMessage(R.string.custom_clear_message)
            .setNegativeButton(R.string.custom_cancel, null)
            .setPositiveButton(R.string.custom_clear_ok) { _, _ ->
                store.clear()
                toast(getString(R.string.toast_custom_cleared))
                refresh()
            }
            .show()
    }

    private fun refresh() {
        val items = store.all()
        adapter.submit(items)
        textSummary.text = getString(R.string.custom_summary, items.size)
        textEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        btnClear.isEnabled = items.isNotEmpty()
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
