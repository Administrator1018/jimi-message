package com.jimi.message

import android.content.Context
import java.util.Calendar

/**
 * 消息时段分类（内部逻辑，界面不展示）。
 * 发送前读取系统时间，只会从「当前时段 + 通用」里挑消息。
 */
enum class Slot(val key: String) {
    ANY("any"),
    DAWN("dawn"),           // 05:00 - 06:59 清晨
    MORNING("morning"),     // 07:00 - 10:59 上午
    NOON("noon"),           // 11:00 - 13:59 午间
    AFTERNOON("afternoon"), // 14:00 - 16:59 下午
    EVENING("evening"),     // 17:00 - 21:59 傍晚
    NIGHT("night"),         // 22:00 - 04:59 深夜
    ;

    companion object {
        fun fromKey(key: String): Slot? = entries.firstOrNull { it.key == key }

        fun of(now: Long): Slot =
            ofHour(Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY))

        fun ofHour(hour: Int): Slot = when (hour) {
            in 5..6 -> DAWN
            in 7..10 -> MORNING
            in 11..13 -> NOON
            in 14..16 -> AFTERNOON
            in 17..21 -> EVENING
            else -> NIGHT
        }
    }
}

data class Message(val tone: Tone, val slot: Slot, val text: String)

/** 抽出来的一条消息：text 是正文，label 是口吻标签（自定义消息显示为「自定义」）。 */
data class PickedMessage(val text: String, val label: String) {
    val key: String get() = label + "#" + text.hashCode()
}

/**
 * 内置消息库：放在 assets 的 messages 目录下，按口吻分文件，
 * 一行一条，格式为「时段|内容」。首次使用时读入内存，之后一直复用。
 */
object MessageBank {

    const val CUSTOM_LABEL = "自定义"

    @Volatile
    private var cache: List<Message>? = null

    private val fallback = listOf(
        Message(Tone.GENTLE, Slot.ANY, "喝口水吧，嗓子会舒服一点。"),
        Message(Tone.SWEET, Slot.ANY, "基米想你了，要好好照顾自己哦。"),
    )

    fun all(context: Context): List<Message> {
        cache?.let { return it }
        synchronized(this) {
            cache?.let { return it }
            val loaded = load(context.applicationContext)
            cache = loaded
            return loaded
        }
    }

    fun totalCount(context: Context): Int = all(context).size

    private fun load(context: Context): List<Message> {
        val result = ArrayList<Message>(1200)
        for (tone in Tone.entries) {
            val text = try {
                context.assets.open("messages/${tone.id}.txt")
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
            } catch (_: Exception) {
                continue
            }
            text.lineSequence().forEach { raw ->
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEach
                val index = line.indexOf('|')
                if (index <= 0) return@forEach
                val slot = Slot.fromKey(line.substring(0, index).trim()) ?: return@forEach
                val body = line.substring(index + 1).trim()
                if (body.isEmpty()) return@forEach
                result += Message(tone, slot, body)
            }
        }
        return if (result.isEmpty()) fallback else result
    }

    /**
     * 抽一条消息。[custom] 是用户自己添加的消息，任何时段都可以出现。
     * 最近发过的内容会优先被排除，避免短时间内重复。
     */
    fun pick(
        context: Context,
        tones: Collection<String>,
        now: Long = System.currentTimeMillis(),
        recentKeys: Set<String> = emptySet(),
        custom: List<String> = emptyList(),
    ): PickedMessage {
        val selected = tones.mapNotNull { Tone.fromId(it) }.ifEmpty { Tone.entries.toList() }
        val slot = Slot.of(now)

        val byTone = all(context).filter { it.tone in selected }
        val slotMatched = byTone.filter { it.slot == slot || it.slot == Slot.ANY }
        val builtin = slotMatched.ifEmpty { byTone }.map { it.text to it.tone.label }

        val candidates = ArrayList<Pair<String, String>>(builtin.size + custom.size)
        candidates += builtin
        custom.forEach { if (it.isNotBlank()) candidates += it.trim() to CUSTOM_LABEL }
        if (candidates.isEmpty()) {
            val message = fallback.random()
            return PickedMessage(message.text, message.tone.label)
        }

        val fresh = candidates.filter { PickedMessage(it.first, it.second).key !in recentKeys }
        val chosen = fresh.ifEmpty { candidates }.random()
        return PickedMessage(chosen.first, chosen.second)
    }
}
