package com.jimi.message

import android.content.Context
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

/** 定时任务：抽一条消息并推送。 */
class MessageWorker(
    appContext: Context,
    params: WorkerParameters,
) : Worker(appContext, params) {

    override fun doWork(): Result {
        val prefs = AppPrefs(applicationContext)
        val forced = inputData.getBoolean(KEY_FORCE, false)

        if (!forced) {
            if (!prefs.enabled) return Result.success()
            if (prefs.inQuietHours()) return Result.success()
        }

        val message = MessageBank.pick(
            context = applicationContext,
            tones = prefs.tones,
            recentKeys = prefs.recentKeys(),
            custom = CustomMessageStore(applicationContext).all(),
        )
        prefs.pushRecentKey(message.key)
        if (!forced) prefs.sentCount = prefs.sentCount + 1
        Notifier.show(applicationContext, message)
        return Result.success()
    }

    companion object {
        const val KEY_FORCE = "force"

        fun oneOff(delayMillis: Long, forced: Boolean): OneTimeWorkRequest =
            OneTimeWorkRequestBuilder<MessageWorker>()
                .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(KEY_FORCE to forced))
                .build()
    }
}
