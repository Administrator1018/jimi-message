package com.jimi.message

import android.content.Context
import android.content.SharedPreferences
import java.util.Calendar

/** 所有设置都保存在本机 SharedPreferences，不涉及任何网络。 */
class AppPrefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("jimi_message_prefs", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean(KEY_ENABLED, false)
        set(value) {
            sp.edit().putBoolean(KEY_ENABLED, value).apply()
        }

    var mode: String
        get() = sp.getString(KEY_MODE, MODE_INTERVAL) ?: MODE_INTERVAL
        set(value) {
            sp.edit().putString(KEY_MODE, value).apply()
        }

    var intervalMinutes: Int
        get() = sp.getInt(KEY_INTERVAL, DEFAULT_INTERVAL)
        set(value) {
            sp.edit().putInt(KEY_INTERVAL, value.coerceIn(MIN_INTERVAL, MAX_INTERVAL)).apply()
        }

    var dailyHour: Int
        get() = sp.getInt(KEY_DAILY_HOUR, 9)
        set(value) {
            sp.edit().putInt(KEY_DAILY_HOUR, value.coerceIn(0, 23)).apply()
        }

    var dailyMinute: Int
        get() = sp.getInt(KEY_DAILY_MINUTE, 30)
        set(value) {
            sp.edit().putInt(KEY_DAILY_MINUTE, value.coerceIn(0, 59)).apply()
        }

    var quietEnabled: Boolean
        get() = sp.getBoolean(KEY_QUIET_ENABLED, true)
        set(value) {
            sp.edit().putBoolean(KEY_QUIET_ENABLED, value).apply()
        }

    var quietStartMinute: Int
        get() = sp.getInt(KEY_QUIET_START, 23 * 60)
        set(value) {
            sp.edit().putInt(KEY_QUIET_START, value.coerceIn(0, 1439)).apply()
        }

    var quietEndMinute: Int
        get() = sp.getInt(KEY_QUIET_END, 7 * 60)
        set(value) {
            sp.edit().putInt(KEY_QUIET_END, value.coerceIn(0, 1439)).apply()
        }

    var nextRunAt: Long
        get() = sp.getLong(KEY_NEXT_RUN, 0L)
        set(value) {
            sp.edit().putLong(KEY_NEXT_RUN, value).apply()
        }

    var sentCount: Int
        get() = sp.getInt(KEY_SENT_COUNT, 0)
        set(value) {
            sp.edit().putInt(KEY_SENT_COUNT, value).apply()
        }

    var tones: Set<String>
        get() {
            val stored = sp.getStringSet(KEY_TONES, null)
            return if (stored.isNullOrEmpty()) Tone.defaultSelection.toSet() else stored.toSet()
        }
        set(value) {
            sp.edit().putStringSet(KEY_TONES, value.toSet()).apply()
        }

    fun recentKeys(): Set<String> {
        val raw = sp.getString(KEY_RECENT, "").orEmpty()
        if (raw.isBlank()) return emptySet()
        return raw.split("|").filter { it.isNotBlank() }.toSet()
    }

    fun pushRecentKey(key: String) {
        val list = ArrayList(recentKeys())
        list.remove(key)
        list.add(key)
        while (list.size > REMEMBER_RECENT) list.removeAt(0)
        sp.edit().putString(KEY_RECENT, list.joinToString("|")).apply()
    }

    fun inQuietHours(now: Long = System.currentTimeMillis()): Boolean {
        if (!quietEnabled) return false
        val start = quietStartMinute
        val end = quietEndMinute
        if (start == end) return false
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val current = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (start < end) current in start until end else (current >= start || current < end)
    }

    companion object {
        const val MODE_INTERVAL = "interval"
        const val MODE_DAILY = "daily"

        const val MIN_INTERVAL = 15
        const val MAX_INTERVAL = 24 * 60
        const val DEFAULT_INTERVAL = 120

        private const val REMEMBER_RECENT = 30

        private const val KEY_ENABLED = "enabled"
        private const val KEY_MODE = "mode"
        private const val KEY_INTERVAL = "interval_minutes"
        private const val KEY_DAILY_HOUR = "daily_hour"
        private const val KEY_DAILY_MINUTE = "daily_minute"
        private const val KEY_QUIET_ENABLED = "quiet_enabled"
        private const val KEY_QUIET_START = "quiet_start"
        private const val KEY_QUIET_END = "quiet_end"
        private const val KEY_TONES = "tones"
        private const val KEY_RECENT = "recent_keys"
        private const val KEY_NEXT_RUN = "next_run_at"
        private const val KEY_SENT_COUNT = "sent_count"
    }
}
