package com.jimi.message

/** 关爱消息的口吻风格（只用于用户选择，时段分类完全在后台完成）。 */
enum class Tone(val id: String, val label: String, val blurb: String) {
    GENTLE("gentle", "温柔", "轻声细语，像有人在身边陪着"),
    GENKI("genki", "元气", "满满活力，给你打气加油"),
    SENPAI("senpai", "学姐", "可靠的学姐式关心与监督"),
    TSUNDERE("tsundere", "傲娇", "嘴上嫌弃，其实很在意你"),
    CALM("calm", "沉稳", "理性克制，像温和的提醒"),
    SWEET("sweet", "撒娇", "黏人又软糯，想要你的回应"),
    HUMOR("humor", "幽默", "一本正经地胡说八道地关心"),
    ;

    companion object {
        fun fromId(id: String): Tone? = entries.firstOrNull { it.id == id }

        val defaultSelection: List<String> = listOf(GENTLE.id, SWEET.id)
    }
}
