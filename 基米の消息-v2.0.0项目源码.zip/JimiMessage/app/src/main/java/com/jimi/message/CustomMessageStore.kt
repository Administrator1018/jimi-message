package com.jimi.message

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/** 用户自己添加的关心消息，全部保存在本机。 */
class CustomMessageStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("jimi_custom_messages", Context.MODE_PRIVATE)

    /** 最新的排在最前面。 */
    fun all(): List<String> = load()

    val size: Int get() = load().size

    /** 返回 true 表示添加成功；内容为空、重复或已满则返回 false。 */
    fun add(raw: String): Boolean {
        val text = raw.trim()
        if (text.isEmpty() || text.length > MAX_LENGTH) return false
        val list = load()
        if (list.contains(text)) return false
        if (list.size >= MAX_COUNT) return false
        list.add(0, text)
        save(list)
        return true
    }

    fun contains(raw: String): Boolean = load().contains(raw.trim())

    val isFull: Boolean get() = load().size >= MAX_COUNT

    fun remove(text: String) {
        val list = load()
        if (list.remove(text)) save(list)
    }

    fun clear() {
        prefs.edit().remove(KEY_MESSAGES).apply()
    }

    private fun load(): MutableList<String> {
        val raw = prefs.getString(KEY_MESSAGES, null) ?: return mutableListOf()
        return try {
            val array = JSONArray(raw)
            MutableList(array.length()) { index -> array.optString(index) }
                .filter { it.isNotBlank() }
                .toMutableList()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    private fun save(list: List<String>) {
        prefs.edit().putString(KEY_MESSAGES, JSONArray(list).toString()).apply()
    }

    companion object {
        const val MAX_LENGTH = 120
        const val MAX_COUNT = 300

        private const val KEY_MESSAGES = "messages"
    }
}
