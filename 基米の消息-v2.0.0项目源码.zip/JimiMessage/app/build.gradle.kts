import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jimi.message"
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    defaultConfig {
        applicationId = "com.jimi.message"
        minSdk = 29
        targetSdk = 36
        versionCode = 2
        versionName = "2.0.0"
        vectorDrawables.useSupportLibrary = true
    }

    signingConfigs {
        create("jimi") {
            val store = rootProject.file("keystore/jimi-release.jks")
            if (store.exists()) {
                storeFile = store
                storePassword = "jimi2026"
                keyAlias = "jimi"
                keyPassword = "jimi2026"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            if (rootProject.file("keystore/jimi-release.jks").exists()) {
                signingConfig = signingConfigs.getByName("jimi")
            }
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        // 本项目全部使用 Kotlin + findViewById，不生成任何 Java 源码
        viewBinding = false
        buildConfig = false
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }

    packaging {
        resources.excludes += setOf("META-INF/*.kotlin_module")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.17")
    testImplementation("androidx.test:core:1.6.1")
    testImplementation("androidx.work:work-testing:2.9.1")
}

tasks.withType<Test>().configureEach {
    val roboHome = project.layout.buildDirectory.dir("robolectric-home").get().asFile
    val tmpDir = File(roboHome, "tmp")
    roboHome.mkdirs()
    doFirst {
        // Robolectric 会把 native 运行时解压到临时目录，每次跑测试前清空避免残留导致解压失败
        tmpDir.deleteRecursively()
        tmpDir.mkdirs()
    }
    // Robolectric 会在 user.home 下写下载锁与本地 maven 缓存
    systemProperty("user.home", roboHome.absolutePath)
    systemProperty("maven.repo.local", File(roboHome, ".m2/repository").absolutePath)
    systemProperty("java.io.tmpdir", tmpDir.absolutePath)
    systemProperty("robolectric.dependency.repo.url", "https://repo.maven.apache.org/maven2")
}
