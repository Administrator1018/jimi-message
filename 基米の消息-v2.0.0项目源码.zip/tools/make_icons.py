"""Generate launcher icons for 基米の消息 from the user's avatar photo."""
import os
from PIL import Image, ImageDraw, ImageOps

SRC = r"D:\LiveWallpaper\头像.jpg"
PROJECT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "JimiMessage")
RES = os.path.join(PROJECT, "app", "src", "main", "res")

DENSITIES = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
LEGACY_DP = 48
FOREGROUND_DP = 108


def load_square() -> Image.Image:
    image = Image.open(SRC).convert("RGB")
    side = min(image.size)
    return ImageOps.fit(image, (side, side), Image.LANCZOS, centering=(0.5, 0.45))


def border_color(square: Image.Image) -> tuple[int, int, int]:
    small = square.resize((64, 64), Image.LANCZOS)
    pixels = []
    for x in range(64):
        for y in range(64):
            if x < 8 or y < 8 or x > 55 or y > 55:
                pixels.append(small.getpixel((x, y)))
    r = sum(p[0] for p in pixels) // len(pixels)
    g = sum(p[1] for p in pixels) // len(pixels)
    b = sum(p[2] for p in pixels) // len(pixels)
    # 稍微提亮，做成柔和的背景色
    return (min(255, int(r * 1.12) + 8), min(255, int(g * 1.12) + 8), min(255, int(b * 1.12) + 8))


def rounded_mask(size: int, radius_ratio: float) -> Image.Image:
    mask = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        (0, 0, size * 4 - 1, size * 4 - 1),
        radius=int(size * 4 * radius_ratio),
        fill=255,
    )
    return mask.resize((size, size), Image.LANCZOS)


def circle_mask(size: int) -> Image.Image:
    mask = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size * 4 - 1, size * 4 - 1), fill=255)
    return mask.resize((size, size), Image.LANCZOS)


def main() -> None:
    square = load_square()
    bg = border_color(square)
    print("icon background:", bg)

    for density, scale in DENSITIES.items():
        folder = os.path.join(RES, f"mipmap-{density}")
        os.makedirs(folder, exist_ok=True)

        legacy_size = int(LEGACY_DP * scale)
        cover = square.resize((legacy_size, legacy_size), Image.LANCZOS)

        legacy = cover.copy()
        legacy.putalpha(rounded_mask(legacy_size, 0.22))
        legacy.save(os.path.join(folder, "ic_launcher.png"))

        round_icon = cover.copy()
        round_icon.putalpha(circle_mask(legacy_size))
        round_icon.save(os.path.join(folder, "ic_launcher_round.png"))

        fg_size = int(FOREGROUND_DP * scale)
        fg = square.resize((fg_size, fg_size), Image.LANCZOS).convert("RGBA")
        fg.save(os.path.join(folder, "ic_launcher_foreground.png"))

    # 同步自适应图标的背景色
    color_file = os.path.join(RES, "values", "ic_launcher_background.xml")
    with open(color_file, "w", encoding="utf-8") as fh:
        fh.write(
            '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
            f'    <color name="ic_launcher_background">#{bg[0]:02X}{bg[1]:02X}{bg[2]:02X}</color>\n'
            "</resources>\n"
        )
    print("icons written to", RES)


if __name__ == "__main__":
    main()
